#include "Animation.hpp"
#include "../RSDL/rsdl.hpp"

using namespace std;

Animation::Animation(vector<string> frame_names,int fps)
{   
    frames = frame_names;
    last_update = clock::now();
    current_frame_index = 0;
    frame_per_seconds = fps;
}

void Animation::set_fps(int fps)
{
    frame_per_seconds = fps;
}

bool Animation::is_frame_change_time()
{
    auto current_time = clock::now();
    time_span passed_time = chrono::duration_cast<time_span>(current_time - last_update);

    if(passed_time.count() >= 1.0 / frame_per_seconds)
    {   
        last_update = current_time;
        return true;
    }

    return false;
}

void Animation::go_to_next_frame()
{
    size_t farmes_count = frames.size();

    current_frame_index ++;
    current_frame_index %= farmes_count;
}

string Animation::get_current_frame_name()
{
    update_frame();

    string image_name;
    try
    {
        image_name = frames[current_frame_index];
    }
    catch(exception e)
    {
        image_name = *frames.begin();   
    }
    return image_name;
}

void Animation::update_frame()
{
    if(is_frame_change_time())
        go_to_next_frame();
}
