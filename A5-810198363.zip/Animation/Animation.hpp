#include <chrono>
#include <string>
#include <vector>

#ifndef ANIMATION_HEADER
#define ANIMATION_HEADER

class Window;

class Animation
{
    private :

    typedef std::chrono::steady_clock clock;
    typedef std::chrono::duration<float> time_span;

    std::vector<std::string>  frames; 
    std::chrono::steady_clock::time_point last_update;

    int frame_per_seconds;
    int current_frame_index;

    void go_to_next_frame();
    bool is_frame_change_time();
    void update_frame();

    public :

    Animation(std::vector<std::string> frame_names,int fps);
    Animation(){};
    void set_fps(int fps);
    
    std::string get_current_frame_name ();
};

#endif