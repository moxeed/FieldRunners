#include "GlueBullet.hpp"
#include "../../Source/World.hpp"

#include <iostream>

using namespace std;

GlueBullet::GlueBullet(int _damage, int _slow_down_time, Point position, Enemy* enemy, World* world)
    : Bullet(250, position, world ,"glue")
{    
    damage = _damage;
    target = enemy;
    slow_down_time = _slow_down_time;
}

void GlueBullet::do_damage()
{
    world->do_areal_slow_down(position, range, damage, slow_down_time);
}