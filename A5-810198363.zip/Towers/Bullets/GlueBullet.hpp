#include "../../Source/Bullet.hpp"

class GlueBullet : public Bullet
{
private:
    int range = 30;
    int slow_down_time;

public:
    GlueBullet(int _damage, int slow_down_time, Point position ,Enemy* enemy ,World* world);
    void do_damage();
};

