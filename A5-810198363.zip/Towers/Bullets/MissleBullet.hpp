#include "../../Source/Bullet.hpp"

class MissleBullet : public Bullet
{
private:
    int range = 50;
public:
    MissleBullet(int _damage ,Point position ,Enemy* enemy ,World* world);
    void do_damage();
};

